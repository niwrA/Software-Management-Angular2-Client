import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productconfig',
  templateUrl: './productconfig.component.html',
  styleUrls: ['./productconfig.component.css']
})
export class ProductConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
