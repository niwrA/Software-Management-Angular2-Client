import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productconfigs',
  templateUrl: './productconfigs.component.html',
  styleUrls: ['./productconfigs.component.css']
})
export class ProductConfigsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
