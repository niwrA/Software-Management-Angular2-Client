import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productissue',
  templateUrl: './productissue.component.html',
  styleUrls: ['./productissue.component.css']
})
export class ProductIssueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
