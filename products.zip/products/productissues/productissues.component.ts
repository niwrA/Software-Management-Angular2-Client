import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productissues',
  templateUrl: './productissues.component.html',
  styleUrls: ['./productissues.component.css']
})
export class ProductIssuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
