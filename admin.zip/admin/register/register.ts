export class Register {
    title: string;
    name: string;
    email: string;
    password: string;
    repassword: string;
}
