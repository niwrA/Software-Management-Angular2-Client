export class Group {
    Guid: string;
    Name: string;
    IsAdmin: boolean;
}
