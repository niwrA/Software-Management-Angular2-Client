export class Login {
    title: string;
    name: string;
    password: string;
}
