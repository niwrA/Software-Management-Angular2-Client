import { User } from './user';
export const USERS: User[] = [
  { guid: 'user11', name: 'joe.smith', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user12', name: 'jane.smith', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user13', name: 'mr.nobody', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user14', name: 'james.bond', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user15', name: 'neo', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user16', name: 'peter.parker', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user17', name: 'hillary.clinton', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user18', name: 'estelle', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user19', name: 'david.bowie', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user20', name: 'maria', email: 'joe.smith@company.com', isAdmin: false },
  { guid: 'user21', name: 'admin', email: 'joe.smith@company.com', isAdmin: true }
];
