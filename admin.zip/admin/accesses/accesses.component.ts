import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accesses',
  templateUrl: './accesses.component.html',
  styleUrls: ['./accesses.component.css']
})
export class AccessesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
