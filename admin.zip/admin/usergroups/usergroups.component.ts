import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usergroups',
  templateUrl: './usergroups.component.html',
  styleUrls: ['./usergroups.component.css']
})
export class UsergroupsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
