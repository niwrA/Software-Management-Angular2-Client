import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-groupaccesses',
  templateUrl: './groupaccesses.component.html',
  styleUrls: ['./groupaccesses.component.css']
})
export class GroupaccessesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
